//
// Created by kstol on 17.10.2026.
//

#ifndef LIST_1_MAIN_H
#define LIST_1_MAIN_H
#include <iostream>

const int I_FILL_VALUE = 34;
const int I_SIZE = 10;

const int I_SIZE_X1 = 5;
const int I_SIZE_X2 = 10;

const int I_SIZE_Y1 = 10;
const int I_SIZE_Y2 = 15;

const int I_SIZE_1 = 10;
const int I_SIZE_2 = 20;

const int I_NEGATIVE_SIZE = -10;

const std::string S_ERROR_INCORRECT = "Wprowadzona wartosc jest nieprawidlowa\n";

const std::string S_TEST_1 = "Zadanie 1";
const std::string S_TEST_2 = "Zadanie 2";
const std::string S_TEST_3 = "Zadanie 3";
const std::string S_TEST_4 = "Zadanie 4";

const std::string S_PROCEDURE_1 = "Procedura 1";
const std::string S_PROCEDURE_2 ="Procedura 2";

const std::string S_MEMORY_ALLOCATION = "Pammiec zaalokowana";
const std::string S_MEMORY_DEALLOCATION = "Pamiec zdealokowana";

const std::string S_NAME = "Name";

const std::string S_X = "x";
const std::string S_L = "L";
const std::string S_R = "R";
const int MOD_SIZE = 6;

#endif //LIST_1_MAIN_H
