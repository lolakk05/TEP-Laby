cmake_minimum_required(VERSION 4.3)
project(List_1)

set(CMAKE_CXX_STANDARD 98)

add_executable(List_1 main.cpp
        main.h
        CTable.cpp
        CTable.h)