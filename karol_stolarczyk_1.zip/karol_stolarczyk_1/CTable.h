//
// Created by kstol on 17.10.2026.
//

#ifndef LIST_1_CTABLE_H
#define LIST_1_CTABLE_H
#include <iostream>

const std::string S_DEFAULT_NAME = "default";
const int I_DEFAULT_LENGTH = 5;

const std::string S_BEZP =  "bezp: ";
const std::string S_COPY = "_copy";
const std::string S_DELETE = "usuwam: ";
const std::string S_COPY_MESSAGE = "kopiuj: ";
const std::string S_PARAM = "parametr: ";
const std::string S_MODIFY = "modyfikuje: ";
const std::string S_MOD_RESULT = "result";

class CTable {
public: CTable();
        CTable(std::string sName, int iTableLen);
        CTable(CTable &pcOther);
        ~CTable();
        void vSetName(std::string sName);
        bool bSetNewSize(int iTableLen);
        CTable *pcClone();

        CTable *select(const CTable &left, const CTable &right);
        void vSetArray(const int *pi_table);
        void printArray();
private:
        std::string s_name;
        int i_table_len;
        int *pi_table;
};


#endif //LIST_1_CTABLE_H
