#include "CTable.h"
#include <iostream>

#include "main.h"

void v_print_message(std::string sMessage, std::string sName) {
    std::cout << sMessage + sName << std::endl;
}

CTable::CTable() :
    s_name(S_DEFAULT_NAME),
    i_table_len(I_DEFAULT_LENGTH),
    pi_table(new int[i_table_len])
{
    v_print_message(S_BEZP, s_name);
}

CTable::CTable(std::string sName, int iTableLen) {
    s_name = sName;
    i_table_len = iTableLen;
    if (iTableLen < 0) {
        i_table_len = I_SIZE_X1;
    }
    pi_table = new int[i_table_len];
    v_print_message(S_PARAM, s_name);
}

CTable::CTable(CTable &pcOther):
    s_name(pcOther.s_name + S_COPY),
    i_table_len(pcOther.i_table_len),
    pi_table(new int[i_table_len])
{
    for (int i = 0; i < i_table_len; i++) {
        pi_table[i] = pcOther.pi_table[i];
    }

    v_print_message(S_COPY_MESSAGE, s_name);
}

CTable::~CTable() {
    if (pi_table != NULL) {
        delete [] pi_table;
    }
    v_print_message(S_DELETE, s_name);
}

void CTable::vSetName(std::string sName) {
    s_name = sName;
}

bool CTable::bSetNewSize(int iTableLen) {
    if (iTableLen <= 0) {
        return false;
    }
    int *pi_new_table;
    pi_new_table = new int[iTableLen];

    int i_to_copy;
    if (iTableLen > i_table_len) {
        i_to_copy = i_table_len;
    } else {
        i_to_copy = iTableLen;
    }

    for (int i = 0; i < i_to_copy; i++) {
        pi_new_table[i] = pi_table[i];
    }

    delete [] pi_table;
    pi_table = pi_new_table;
    i_table_len = iTableLen;
    return true;
}

CTable *CTable::pcClone() {
    return new CTable(*this);
}

CTable *CTable::select(const CTable &left, const CTable &right) {
    if (left.i_table_len <= 0 || right.i_table_len <= 0 || this->i_table_len <= 0) {
        std::cout << S_ERROR_INCORRECT << std::endl;
    }

    int i_min_len = std::min(left.i_table_len, right.i_table_len);
    i_min_len = std::min(i_min_len, this->i_table_len);

    CTable result_table(S_MOD_RESULT, i_min_len);

    for (int i = 0; i < i_min_len; i++) {
        if (this->pi_table[i] > 0) {
            result_table.pi_table[i] = left.pi_table[i];
        }
        else {
            result_table.pi_table[i] = right.pi_table[i];
        }
    }

    return &result_table;
}

void CTable::vSetArray(const int *pi_arr) {
    for (int i = 0; i < this->i_table_len; i++) {
        pi_table[i] = pi_arr[i];
    }
}

void CTable::printArray() {
    for (int i = 0; i < this->i_table_len; i++) {
        std::cout << this->pi_table[i] << " ";
    }
    std::cout << std::endl;
}