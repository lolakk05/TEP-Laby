#include <iostream>
#include "main.h"
#include "CTable.h"

void v_alloc_table_fill_34(int iSize) {
    if (iSize <= 0) {
        std::cout << S_ERROR_INCORRECT;
        return;
    }

    int *pi_table;
    pi_table = new int[iSize];
    for (int i = 0; i < iSize; i++) {
        pi_table[i] = I_FILL_VALUE;
    }

    for (int i = 0; i < iSize; i++) {
        std::cout << pi_table[i] << " ";
    }

    std::cout << std::endl;

    delete [] pi_table;
}

bool b_alloc_table_2_dim(int ***piTable, int iSizeX, int iSizeY) {
    if (iSizeX <= 0 || iSizeY <= 0  || piTable == NULL) {
        std::cout << S_ERROR_INCORRECT;
        return false;
    }

    int **pi_table;
    pi_table = new int*[iSizeX];

    for (int i = 0; i < iSizeX; i++) {
        *(pi_table+i) = new int[iSizeY]; //pi_table[i] - dla kompilatora to samo
    }

    *piTable = pi_table;

    return true;
}

bool b_dealloc_table_2_dim(int **piTable, int iSizeX, int iSizeY) {
    if (iSizeX <= 0 || iSizeY <= 0 || piTable == NULL) {
        std::cout << S_ERROR_INCORRECT;
        return false;
    }

    for (int i = 0; i < iSizeX; i++) {
        if (piTable[i] != NULL) {
            delete [] piTable[i];
        }
    }

    delete [] piTable;

    return true;
}

void v_mod_tab(CTable *pcTab, int iNewSize) {
    if (pcTab != NULL) {
        pcTab -> bSetNewSize(iNewSize);
    }
}

void v_mod_tab(CTable cTab, int iNewSize) {
    cTab.bSetNewSize(iNewSize);
}


int main() {
    std::cout << S_TEST_1 << std::endl;
    v_alloc_table_fill_34(I_SIZE);
    v_alloc_table_fill_34(0);
    v_alloc_table_fill_34(I_NEGATIVE_SIZE);

    std::cout << S_TEST_2 << std::endl;
    int **piTable;
    b_alloc_table_2_dim(&piTable, I_SIZE_X1, I_SIZE_Y1);
    std::cout << S_MEMORY_ALLOCATION << std::endl;

    std::cout << S_TEST_3 << std::endl;
    if (b_dealloc_table_2_dim(piTable, I_SIZE_X1, I_SIZE_Y1)) {
        std::cout << S_MEMORY_DEALLOCATION << std::endl;
        piTable = NULL;
    }

    std::cout << S_TEST_4 << std::endl;
    CTable c_my_table;
    v_mod_tab(&c_my_table, I_SIZE_1);
    v_mod_tab(c_my_table, I_SIZE_2);

    CTable *pc_clone = c_my_table.pcClone();

    CTable cTable(S_NAME, I_NEGATIVE_SIZE);
    delete pc_clone;

    CTable *pc_table_arr = new CTable[I_SIZE_X1];
    delete [] pc_table_arr;

    //MOD
    int x_arr[] = {1, -1, 3, 5, 7, 0};
    int l_arr[] = {1, 1, 2, 3, 5, 8};
    int r_arr[] = {2, 1, 3, 7, 6, 7};

    CTable x(S_X, MOD_SIZE);
    CTable left(S_L, MOD_SIZE);
    CTable right(S_R, MOD_SIZE);

    x.vSetArray(x_arr);
    left.vSetArray(l_arr);
    right.vSetArray(r_arr);

    x.printArray();

    CTable *result = x.select(left, right);
    delete result;

    int x_arr1[] = {1, -1, 3, 5, 7, 0};
    int l_arr1[] = {1, 1, 2, 3, 5};
    int r_arr1[] = {2, 1, 3};

    CTable x1(S_X, 6);
    CTable left1(S_L, 5);
    CTable right1(S_R, 3);

    x1.vSetArray(x_arr1);
    left1.vSetArray(l_arr1);
    right1.vSetArray(r_arr1);

    CTable *result1 = x1.select(left1, right1);
    delete result1;

    return 0;
}